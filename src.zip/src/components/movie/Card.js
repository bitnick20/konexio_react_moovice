import React from 'react';
import placeholder from '../../placeholder.png';


class Card extends React.Component {
    constructor (props) {
        super(props);
        
        this.state = {
            source: placeholder
        }
    }
    render () {
        return (
            <div>
                <img src={this.state.source}/>
            </div>
        );
    }

}

export default Card;