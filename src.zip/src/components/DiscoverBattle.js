import React from 'react';


class DiscoverBattle extends React.Component {
    render () {
        return (
            <div>
                DiscoverBattle
            </div>
        );
    }
}

export default DiscoverBattle;
