import React from 'react';
import Card from './movie/Card';


class Popular extends React.Component {
    constructor (props) {
        super(props);

        this.state = {
            movies: []
        }

    }

    componentDidMount () {
        const url = 'https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=4761f779a2abf8d89a78b9b94bfde5ab'
        console.log("cmp/Popular :",url);

        fetch(url)
            .then(res => res.json())
            .then(json => {
                console.log("cmp/Popular#fetch :",json);
                this.setState({
                    movies: json.movies
                });
            });
    }
    
    // ATTENTION EN ATTENTE ETAPE 3 RECUPERATION DES FILMS

    render () {
        console.log("cmp/Popular#render :", this.state);
        const { 
            movies 
        } = this.state;
        return (
            <div>
                Popular
                <Card movies={movies}/> 
            </div>
        );
    }
}

export default Popular;
