import React from 'react';
import './MyList.css';

class MyList extends React.Component {
    render () {
        return (
            <div>
                MyList
            </div>
        );
    }
}

export default MyList;
