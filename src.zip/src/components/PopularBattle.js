import React from 'react';


class PopularBattle extends React.Component {
    render () {
        return (
            <div>
                PopularBattle
            </div>
        );
    }
}

export default PopularBattle;
