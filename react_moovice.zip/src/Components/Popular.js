import React from 'react';
import Card from './movie/Card';


class Popular extends React.Component {
    constructor (props) {
        super (props);

        this.state = {
            movies: []
        }
    }

    render () {
        return (
            <div>
                Popular
                <Card />
            </div>
        );
    }
}

export default Popular;
