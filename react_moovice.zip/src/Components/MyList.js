import React from 'react';


class MyList extends React.Component {
    render () {
        return (
            <div>
                MyList
            </div>
        );
    }
}

export default MyList;
