import React from 'react';


class PopularBattle extends React.Component {
    render () {
        return (
            <div>
                DiscoverBattle
            </div>
        );
    }
}

export default PopularBattle;
